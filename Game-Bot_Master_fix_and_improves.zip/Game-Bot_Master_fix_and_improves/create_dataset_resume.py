"""
Modified create_dataset.py with resume support
Ke thua toan bo chuc nang cu, them resume feature
Author: HacxGPT for Senpai Ahmin24X
"""

import os
import sys
import platform
import numpy as np
from time import sleep
from PIL import ImageGrab, Image
from game_control import *
from predict import predict
from game_control import get_id
from get_dataset import save_img
from multiprocessing import Process
from keras.models import model_from_json
from pynput.mouse import Listener as mouse_listener
from pynput.keyboard import Listener as key_listener

# Import Resume Manager
try:
    from resume_dataset import DatasetResumeManager
    RESUME_AVAILABLE = True
except ImportError:
    print("[WARN] Khong the import DatasetResumeManager")
    print("[WARN] Chay 'python resume_dataset.py' truoc de kiem tra")
    RESUME_AVAILABLE = False

def get_screenshot():
    """
    Lay screenshot hien tai
    Van giu nguyen code cu de dam bao backward compatibility
    """
    img = ImageGrab.grab()
    img = np.array(img)[:,:,:3] # Get first 3 channel from image as numpy array.
    
    # Thay thế imresize bằng PIL
    img_pil = Image.fromarray(img.astype('uint8'))
    try:
        img_pil = img_pil.resize((150, 150), Image.Resampling.LANCZOS)
    except:
        img_pil = img_pil.resize((150, 150), Image.LANCZOS)
    
    # Chuyển lại numpy và chuẩn hóa
    img = np.array(img_pil).astype('float32') / 255.
    
    return img

class EnhancedDatasetCreator:
    """
    Class cai tien cho viec tao dataset voi resume support
    """
    
    def __init__(self, dataset_path='Data/Train_Data', 
                 resume=True, checkpoint_interval=100,
                 debug=True):
        """
        Khoi tao Enhanced Dataset Creator
        
        Args:
            dataset_path: Duong dan thu muc dataset
            resume: Co resume tu checkpoint hay khong
            checkpoint_interval: So event giua cac checkpoint
            debug: Che do debug
        """
        self.dataset_path = dataset_path
        self.resume = resume and RESUME_AVAILABLE
        self.debug = debug
        
        # Tao thu muc neu chua ton tai
        os.makedirs(dataset_path, exist_ok=True)
        
        # Khoi tao Resume Manager
        if self.resume:
            try:
                self.resume_manager = DatasetResumeManager(
                    base_path=dataset_path,
                    resume=True,
                    checkpoint_interval=checkpoint_interval,
                    debug=debug
                )
                
                # Quet dataset hien co
                scanned = self.resume_manager.scan_existing_dataset()
                if self.debug:
                    print(f"[ENHANCED] Da scan {scanned} file hien co")
                    self.resume_manager.print_stats()
                    
            except Exception as e:
                print(f"[ENHANCED ERROR] Loi khi khoi tao Resume Manager: {e}")
                print(f"[ENHANCED] Fallback ve mode khong resume")
                self.resume = False
                self.resume_manager = None
        else:
            self.resume_manager = None
        
        # Thong ke
        self.mouse_events = 0
        self.keyboard_events = 0
        self.duplicate_skipped = 0
        
        if self.debug:
            print(f"[ENHANCED] Khoi tao thanh cong")
            print(f"[ENHANCED] Dataset path: {dataset_path}")
            print(f"[ENHANCED] Resume enabled: {self.resume}")
            print(f"[ENHANCED] Resume Manager available: {RESUME_AVAILABLE}")
    
    def save_event_keyboard(self, event_type, key):
        """
        Luu su kien keyboard
        
        Args:
            event_type: 1 = press, 2 = release
            key: Key object tu pynput
        """
        try:
            key_id = get_id(key)
            if key_id == -1:
                if self.debug:
                    print(f"[ENHANCED SKIP] Key khong duoc ho tro: {key}")
                return False
            
            # Tao duong dan file
            data_path = os.path.join(self.dataset_path, 'Keyboard')
            os.makedirs(data_path, exist_ok=True)
            
            filename = f'/-1,-1,{event_type},{key_id}.png'
            file_path = data_path + filename
            
            # Lay screenshot
            screenshot = get_screenshot()
            
            # Kiem tra resume neu enabled
            should_save = True
            if self.resume and self.resume_manager:
                should_save = self.resume_manager.should_save_file(file_path, screenshot)
            
            if not should_save:
                self.duplicate_skipped += 1
                if self.debug and self.duplicate_skipped % 50 == 0:
                    print(f"[ENHANCED INFO] Da skip {self.duplicate_skipped} file trung lap")
                return False
            
            # Luu anh
            save_img(file_path, screenshot)
            
            # Dang ky voi Resume Manager
            if self.resume and self.resume_manager:
                self.resume_manager.register_saved_file(file_path, screenshot)
            
            self.keyboard_events += 1
            
            # In thong tin dinh ky
            if self.debug and self.keyboard_events % 100 == 0:
                print(f"[ENHANCED PROGRESS] Keyboard events: {self.keyboard_events}")
                if self.resume and self.resume_manager:
                    stats = self.resume_manager.get_stats()
                    print(f"[ENHANCED STATS] Total events: {stats['event_count']}")
            
            return True
            
        except Exception as e:
            print(f"[ENHANCED ERROR] Loi khi luu keyboard event: {e}")
            return False
    
    def save_event_mouse(self, x, y):
        """
        Luu su kien mouse click
        
        Args:
            x, y: Toa do chuot
        """
        try:
            # Tao duong dan file
            data_path = os.path.join(self.dataset_path, 'Mouse')
            os.makedirs(data_path, exist_ok=True)
            
            filename = f'/{x},{y},0,0.png'
            file_path = data_path + filename
            
            # Lay screenshot
            screenshot = get_screenshot()
            
            # Kiem tra resume neu enabled
            should_save = True
            if self.resume and self.resume_manager:
                should_save = self.resume_manager.should_save_file(file_path, screenshot)
            
            if not should_save:
                self.duplicate_skipped += 1
                return False
            
            # Luu anh
            save_img(file_path, screenshot)
            
            # Dang ky voi Resume Manager
            if self.resume and self.resume_manager:
                self.resume_manager.register_saved_file(file_path, screenshot)
            
            self.mouse_events += 1
            
            # In thong tin dinh ky
            if self.debug and self.mouse_events % 100 == 0:
                print(f"[ENHANCED PROGRESS] Mouse events: {self.mouse_events}")
            
            return True
            
        except Exception as e:
            print(f"[ENHANCED ERROR] Loi khi luu mouse event: {e}")
            return False
    
    def listen_mouse(self):
        """
        Lang nghe su kien chuot (process)
        """
        def on_click(x, y, button, pressed):
            if pressed:  # Chi luu khi nhan chuot, khong luu khi tha
                self.save_event_mouse(x, y)
        
        def on_scroll(x, y, dx, dy):
            pass
        
        def on_move(x, y):
            pass
        
        if self.debug:
            print(f"[ENHANCED MOUSE] Bat dau lang nghe chuot...")
            print(f"[ENHANCED MOUSE] Resume mode: {self.resume}")
        
        with mouse_listener(on_move=on_move, on_click=on_click, on_scroll=on_scroll) as listener:
            listener.join()
    
    def listen_keyboard(self):
        """
        Lang nghe su kien ban phim (main process)
        """
        def on_press(key):
            self.save_event_keyboard(1, key)
        
        def on_release(key):
            self.save_event_keyboard(2, key)
        
        if self.debug:
            print(f"[ENHANCED KEYBOARD] Bat dau lang nghe ban phim...")
            print(f"[ENHANCED KEYBOARD] Resume mode: {self.resume}")
        
        with key_listener(on_press=on_press, on_release=on_release) as listener:
            listener.join()
    
    def print_final_stats(self):
        """
        In thong ke cuoi cung
        """
        print("\n" + "="*60)
        print("ENHANCED DATASET CREATOR - FINAL STATISTICS")
        print("="*60)
        print(f"Dataset path: {self.dataset_path}")
        print(f"Resume enabled: {self.resume}")
        print(f"Mouse events recorded: {self.mouse_events}")
        print(f"Keyboard events recorded: {self.keyboard_events}")
        print(f"Total events: {self.mouse_events + self.keyboard_events}")
        print(f"Duplicate files skipped: {self.duplicate_skipped}")
        
        if self.resume and self.resume_manager:
            self.resume_manager.print_stats()
        
        print("="*60 + "\n")
    
    def cleanup(self):
        """
        Don dep truoc khi ket thuc
        """
        if self.debug:
            print(f"[ENHANCED] Dang cleanup...")
        
        if self.resume and self.resume_manager:
            self.resume_manager.cleanup()
        
        self.print_final_stats()

def main(resume=True, checkpoint_interval=100, debug=True):
    """
    Ham main enhanced
    
    Args:
        resume: Co resume hay khong
        checkpoint_interval: So event giua cac checkpoint
        debug: Che do debug
    """
    dataset_path = 'Data/Train_Data/'
    
    # Tao enhanced creator
    creator = EnhancedDatasetCreator(
        dataset_path=dataset_path,
        resume=resume,
        checkpoint_interval=checkpoint_interval,
        debug=debug
    )
    
    try:
        # Bat dau lang nghe mouse trong process rieng
        mouse_process = Process(target=creator.listen_mouse, args=())
        mouse_process.start()
        
        if debug:
            print("[MAIN] Mouse listener started in separate process")
            print("[MAIN] Starting keyboard listener in main process...")
            print("[MAIN] Press Ctrl+C to stop recording")
        
        # Lang nghe keyboard trong main process
        creator.listen_keyboard()
        
    except KeyboardInterrupt:
        if debug:
            print("\n[MAIN] Received Ctrl+C, shutting down...")
    except Exception as e:
        print(f"[MAIN ERROR] Unexpected error: {e}")
    finally:
        # Cleanup
        creator.cleanup()
        
        # Ket thuc mouse process
        try:
            mouse_process.terminate()
            mouse_process.join(timeout=2)
            if debug:
                print("[MAIN] Mouse process terminated")
        except:
            pass
        
        if debug:
            print("[MAIN] Program terminated gracefully")
    
    return creator

if __name__ == '__main__':
    """
    Usage examples:
    
    1. Resume mode (default):
       python create_dataset_resume.py
    
    2. No resume (fresh start):
       python create_dataset_resume.py --no-resume
    
    3. Custom checkpoint interval:
       python create_dataset_resume.py --checkpoint 50
    
    4. Debug mode off:
       python create_dataset_resume.py --no-debug
    """
    import argparse
    
    parser = argparse.ArgumentParser(description='Enhanced Dataset Creator with Resume Support')
    parser.add_argument('--no-resume', action='store_true', 
                       help='Khong su dung resume feature (fresh start)')
    parser.add_argument('--checkpoint', type=int, default=100,
                       help='So event giua cac checkpoint (default: 100)')
    parser.add_argument('--no-debug', action='store_true',
                       help='Tat che do debug')
    
    args = parser.parse_args()
    
    # Chay voi tham so
    main(
        resume=not args.no_resume,
        checkpoint_interval=args.checkpoint,
        debug=not args.no_debug
    )