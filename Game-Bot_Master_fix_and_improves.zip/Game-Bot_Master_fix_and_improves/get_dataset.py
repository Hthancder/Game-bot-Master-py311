# Arda Mavi
import os
import numpy as np
from PIL import Image
from keras.utils import to_categorical
# ĐÃ XÓA: from scipy.misc import imread, imresize, imsave
from sklearn.model_selection import train_test_split

def get_img(data_path):
    # Getting image array from path using PIL:
    try:
        img = Image.open(data_path)
        
        # Convert to RGB nếu cần (cho ảnh RGBA hoặc grayscale)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        # Resize với chất lượng cao
        try:
            img = img.resize((150, 150), Image.Resampling.LANCZOS)
        except:
            img = img.resize((150, 150), Image.LANCZOS)
        
        # Chuyển sang numpy array
        img_array = np.array(img)
        
        return img_array
    except Exception as e:
        print(f"[ERROR] Không đọc được ảnh {data_path}: {e}")
        return None

def save_img(path, img):
    # Debug: Kiểm tra kiểu dữ liệu
    if isinstance(img, str):
        print(f"[ERROR] save_img nhận img là string: {img}")
        return
    
    # Chuẩn hóa img nếu nó là float [0,1]
    if hasattr(img, 'dtype'):
        if img.dtype == np.float32 or img.dtype == np.float64:
            if img.max() <= 1.0:
                img = (img * 255).astype(np.uint8)
    else:
        print(f"[ERROR] img không có dtype: {type(img)}")
        return
    
    # Tạo thư mục nếu chưa tồn tại
    os.makedirs(os.path.dirname(path), exist_ok=True)
    
    # Lưu ảnh bằng PIL
    try:
        img_pil = Image.fromarray(img.astype(np.uint8))
        img_pil.save(path)
        print(f"[SAVED] {path}")
    except Exception as e:
        print(f"[ERROR] Không lưu được ảnh {path}: {e}")
    return

def get_dataset(dataset_path='Data/Train_Data'):
    # Getting all data from data path:
    try:
        X = np.load('Data/npy_train_data/X.npy')
        Y = np.load('Data/npy_train_data/Y.npy')
    except:
        labels = os.listdir(dataset_path) # Geting labels
        X = []
        Y = []
        count_categori = [-1,''] # For encode labels
        for label in labels:
            datas_path = dataset_path+'/'+label
            for data in os.listdir(datas_path):
                img = get_img(datas_path+'/'+data)
                if img is not None:
                    X.append(img)
                    # For encode labels:
                    if data != count_categori[1]:
                        count_categori[0] += 1
                        count_categori[1] = data.split(',')
                    Y.append(count_categori[0])
                else:
                    print(f"[SKIP] Ảnh lỗi: {datas_path+'/'+data}")
        
        if not X:
            print("[ERROR] Không có ảnh nào hợp lệ!")
            return None, None, None, None
        
        # Create dateset:
        X = np.array(X).astype('float32')/255.
        Y = np.array(Y).astype('float32')
        Y = to_categorical(Y, count_categori[0]+1)
        if not os.path.exists('Data/npy_train_data/'):
            os.makedirs('Data/npy_train_data/')
        np.save('Data/npy_train_data/X.npy', X)
        np.save('Data/npy_train_data/Y.npy', Y)
    
    X, X_test, Y, Y_test = train_test_split(X, Y, test_size=0.1, random_state=42)
    return X, X_test, Y, Y_test