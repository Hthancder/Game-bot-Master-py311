# Arda Mavi
import os
from keras.models import Model
from keras.optimizers import Adadelta, Adam
from keras.layers import Input, Conv2D, Activation, MaxPooling2D, Flatten, Dense, Dropout, BatchNormalization
from keras.regularizers import l2

def save_model(model):
    if not os.path.exists('Data/Model/'):
        os.makedirs('Data/Model/')
    
    # Save model architecture as JSON
    model_json = model.to_json()
    with open("Data/Model/model.json", "w") as model_file:
        model_file.write(model_json)
    
    # Save weights
    model.save_weights("Data/Model/weights.h5")
    
    # Save full model (Keras .h5 format)
    model.save("Data/Model/full_model.h5")
    
    print('[INFO] Đã lưu model (JSON, weights, full model)')
    return

def get_model(optimizer='adam', learning_rate=0.001):
    inputs = Input(shape=(150, 150, 3))

    # Conv Block 1
    conv_1 = Conv2D(32, (3,3), padding='same', kernel_regularizer=l2(1e-4))(inputs)
    bn_1 = BatchNormalization()(conv_1)
    act_1 = Activation('relu')(bn_1)
    
    # Conv Block 2
    conv_2 = Conv2D(64, (3,3), padding='same', kernel_regularizer=l2(1e-4))(act_1)
    bn_2 = BatchNormalization()(conv_2)
    act_2 = Activation('relu')(bn_2)
    
    # Pooling 1
    pooling_1 = MaxPooling2D(pool_size=(2, 2), strides=(2, 2))(act_2)
    drop_1 = Dropout(0.25)(pooling_1)

    # Conv Block 3
    conv_3 = Conv2D(64, (3,3), padding='same', kernel_regularizer=l2(1e-4))(drop_1)
    bn_3 = BatchNormalization()(conv_3)
    act_3 = Activation('relu')(bn_3)

    # Conv Block 4
    conv_4 = Conv2D(128, (3,3), padding='same', kernel_regularizer=l2(1e-4))(act_3)
    bn_4 = BatchNormalization()(conv_4)
    act_4 = Activation('relu')(bn_4)

    # Pooling 2
    pooling_2 = MaxPooling2D(pool_size=(2, 2), strides=(2, 2))(act_4)
    drop_2 = Dropout(0.25)(pooling_2)

    # Flatten
    flat_1 = Flatten()(drop_2)

    # Fully Connected
    fc = Dense(1280, kernel_regularizer=l2(1e-4))(flat_1)
    fc = BatchNormalization()(fc)
    fc = Activation('relu')(fc)
    fc = Dropout(0.5)(fc)
    
    # Output layer - 4 units
    # CHÚ Ý: Sigmoid cho multi-label, Softmax cho multi-class
    # Cần check dataset để biết dùng cái nào
    fc = Dense(4)(fc)
    outputs = Activation('sigmoid')(fc)  # Hoặc 'softmax'

    # Create model
    model = Model(inputs=inputs, outputs=outputs)

    # Compile với optimizer tùy chọn
    if optimizer.lower() == 'adam':
        opt = Adam(learning_rate=learning_rate)
    elif optimizer.lower() == 'adadelta':
        opt = Adadelta(learning_rate=learning_rate, rho=0.95)
    else:
        opt = Adadelta()  # default
    
    # CHÚ Ý: Nếu dùng sigmoid → binary_crossentropy (multi-label)
    #        Nếu dùng softmax → categorical_crossentropy (multi-class)
    model.compile(
        loss='binary_crossentropy',  # Hoặc 'categorical_crossentropy'
        optimizer=opt,
        metrics=['accuracy', 'binary_accuracy']  # Thêm metrics
    )
    
    return model

def get_model_summary():
    """In model summary"""
    model = get_model()
    model.summary()
    return model

if __name__ == '__main__':
    # Test và save model mẫu
    model = get_model()
    model.summary()
    save_model(model)
    print("[INFO] Model đã được tạo và lưu")