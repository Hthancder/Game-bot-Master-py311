# Arda Mavi
import numpy as np
from PIL import Image
import io

def predict(model, X):
    # Kiểm tra kiểu dữ liệu đầu vào
    if isinstance(X, np.ndarray):
        # Chuyển numpy array sang PIL Image
        if X.ndim == 3:
            # Nếu X là ảnh màu (height, width, channels)
            mode = 'RGB' if X.shape[2] == 3 else 'L'
            img = Image.fromarray((X * 255).astype('uint8'), mode=mode)
        else:
            # Nếu X là ảnh xám hoặc dạng khác
            img = Image.fromarray((X * 255).astype('uint8'))
    else:
        # Nếu X đã là PIL Image
        img = X
    
    # Resize ảnh
    img = img.resize((150, 150), Image.Resampling.LANCZOS)
    
    # Chuyển về numpy array và chuẩn hóa
    X_resized = np.array(img).astype('float32') / 255.
    
    # Đảm bảo shape đúng (150, 150, 3)
    if X_resized.ndim == 2:  # Ảnh xám
        X_resized = np.stack([X_resized] * 3, axis=-1)
    elif X_resized.shape[2] == 4:  # Ảnh RGBA
        X_resized = X_resized[:, :, :3]  # Bỏ kênh alpha
    
    Y = model.predict(X_resized.reshape(1, 150, 150, 3))
    return Y