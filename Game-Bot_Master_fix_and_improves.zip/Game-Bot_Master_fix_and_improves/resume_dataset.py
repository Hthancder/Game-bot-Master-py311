"""
Module resume_dataset.py
Chuc nang: Resume dataset recording tu diem dung
Author: HacxGPT for Senpai Ahmin24X
Date: Now
Features:
- Tu dong phat hien va resume tu checkpoint
- Kiem tra trung lap file (md5 checksum)
- Luu checkpoint sau moi batch
- Backward compatible voi dataset cu
Debug mode: Enabled
"""

import os
import sys
import hashlib
import json
import time
from pathlib import Path
from datetime import datetime

class DatasetResumeManager:
    """
    Quan ly viec resume dataset recording
    """
    
    def __init__(self, base_path='Data/Train_Data', resume=True, 
                 checkpoint_interval=50, debug=True):
        """
        Khoi tao Resume Manager
        
        Args:
            base_path: Duong dan thu muc dataset
            resume: Co resume tu checkpoint hay khong
            checkpoint_interval: So luong event giua moi lan luu checkpoint
            debug: Che do debug
        """
        self.base_path = Path(base_path)
        self.resume = resume
        self.checkpoint_interval = checkpoint_interval
        self.debug = debug
        
        # Tao thu muc neu chua ton tai
        self.base_path.mkdir(parents=True, exist_ok=True)
        
        # Duong dan file checkpoint
        self.checkpoint_file = self.base_path / '.resume_checkpoint.json'
        
        # Counter
        self.event_count = 0
        self.last_checkpoint = 0
        
        # Danh sach file da ghi (de tranh trung lap)
        self.existing_files = set()
        self.existing_hashes = set()
        
        # Debug info
        if self.debug:
            print(f"[RESUME DEBUG] Khoi tao Resume Manager")
            print(f"[RESUME DEBUG] Base path: {self.base_path}")
            print(f"[RESUME DEBUG] Resume mode: {resume}")
            print(f"[RESUME DEBUG] Checkpoint file: {self.checkpoint_file}")
        
        # Load checkpoint neu resume
        if self.resume:
            self._load_checkpoint()
    
    def _load_checkpoint(self):
        """
        Tai checkpoint tu file
        """
        try:
            if self.checkpoint_file.exists():
                with open(self.checkpoint_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                
                # Load thong tin co ban
                self.last_checkpoint = data.get('last_checkpoint', 0)
                self.event_count = data.get('event_count', 0)
                loaded_files = data.get('existing_files', [])
                loaded_hashes = data.get('existing_hashes', [])
                
                # Chuyen ve set
                self.existing_files = set(loaded_files)
                self.existing_hashes = set(loaded_hashes)
                
                if self.debug:
                    print(f"[RESUME DEBUG] Da tai checkpoint")
                    print(f"[RESUME DEBUG] Event count: {self.event_count}")
                    print(f"[RESUME DEBUG] Files tracked: {len(self.existing_files)}")
                    print(f"[RESUME DEBUG] Hashes tracked: {len(self.existing_hashes)}")
                    print(f"[RESUME DEBUG] Last checkpoint: {self.last_checkpoint}")
                    
                    # Hien thi cac thu muc con
                    mouse_path = self.base_path / 'Mouse'
                    keyboard_path = self.base_path / 'Keyboard'
                    
                    if mouse_path.exists():
                        mouse_files = list(mouse_path.glob('*.png'))
                        print(f"[RESUME DEBUG] Mouse files: {len(mouse_files)}")
                    
                    if keyboard_path.exists():
                        keyboard_files = list(keyboard_path.glob('*.png'))
                        print(f"[RESUME DEBUG] Keyboard files: {len(keyboard_files)}")
                
                return True
            else:
                if self.debug:
                    print(f"[RESUME DEBUG] Khong tim thay checkpoint file")
                return False
                
        except Exception as e:
            if self.debug:
                print(f"[RESUME ERROR] Loi khi load checkpoint: {e}")
            return False
    
    def _save_checkpoint(self):
        """
        Luu checkpoint hien tai
        """
        try:
            checkpoint_data = {
                'timestamp': datetime.now().isoformat(),
                'event_count': self.event_count,
                'last_checkpoint': self.last_checkpoint,
                'existing_files': list(self.existing_files),
                'existing_hashes': list(self.existing_hashes),
                'total_files': len(self.existing_files),
                'base_path': str(self.base_path)
            }
            
            with open(self.checkpoint_file, 'w', encoding='utf-8') as f:
                json.dump(checkpoint_data, f, indent=2, ensure_ascii=False)
            
            if self.debug:
                print(f"[RESUME DEBUG] Da luu checkpoint")
                print(f"[RESUME DEBUG] Event count: {self.event_count}")
                print(f"[RESUME DEBUG] Total files: {len(self.existing_files)}")
            
            return True
            
        except Exception as e:
            if self.debug:
                print(f"[RESUME ERROR] Loi khi luu checkpoint: {e}")
            return False
    
    def calculate_file_hash(self, file_path):
        """
        Tinh md5 hash cua file
        
        Args:
            file_path: Duong dan toi file
            
        Returns:
            md5 hash string hoac None neu loi
        """
        try:
            if not isinstance(file_path, Path):
                file_path = Path(file_path)
            
            if not file_path.exists():
                return None
            
            # Tinh hash voi buffer 8192 bytes
            md5_hash = hashlib.md5()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    md5_hash.update(chunk)
            
            return md5_hash.hexdigest()
            
        except Exception as e:
            if self.debug:
                print(f"[RESUME ERROR] Loi khi tinh hash: {e}")
            return None
    
    def scan_existing_dataset(self):
        """
        Quet toan bo dataset hien co
        De tranh trung lap khi resume
        """
        try:
            # Quet tat ca file .png trong thu muc dataset
            png_files = list(self.base_path.rglob('*.png'))
            
            for png_file in png_files:
                # Them vao danh sach file
                self.existing_files.add(str(png_file))
                
                # Tinh hash va them vao danh sach
                file_hash = self.calculate_file_hash(png_file)
                if file_hash:
                    self.existing_hashes.add(file_hash)
            
            if self.debug:
                print(f"[RESUME DEBUG] Da scan {len(png_files)} file PNG")
                print(f"[RESUME DEBUG] Unique hashes: {len(self.existing_hashes)}")
                
                # Phan tich cau truc thu muc
                print(f"[RESUME DEBUG] Phan tich cau truc thu muc:")
                for item in self.base_path.iterdir():
                    if item.is_dir():
                        sub_files = list(item.rglob('*.png'))
                        print(f"  {item.name}: {len(sub_files)} files")
            
            return len(png_files)
            
        except Exception as e:
            if self.debug:
                print(f"[RESUME ERROR] Loi khi scan dataset: {e}")
            return 0
    
    def should_save_file(self, file_path, image_data=None):
        """
        Kiem tra xem co nen luu file hay khong
        De tranh trung lap
        
        Args:
            file_path: Duong dan file du kien
            image_data: Du lieu anh (numpy array) de tinh hash
            
        Returns:
            True neu nen luu, False neu trung lap
        """
        try:
            file_path = Path(file_path)
            
            # Kiem tra 1: File da ton tai chua?
            if str(file_path) in self.existing_files:
                if self.debug:
                    print(f"[RESUME WARN] File da ton tai: {file_path.name}")
                return False
            
            # Kiem tra 2: Tinh hash cua image_data neu co
            if image_data is not None:
                try:
                    # Chuyen image_data thanh bytes de tinh hash
                    import numpy as np
                    if isinstance(image_data, np.ndarray):
                        # Dung tobytes() cho nhanh
                        image_bytes = image_data.tobytes()
                        data_hash = hashlib.md5(image_bytes).hexdigest()
                        
                        if data_hash in self.existing_hashes:
                            if self.debug:
                                print(f"[RESUME WARN] Image hash da ton tai")
                            return False
                except Exception as e:
                    if self.debug:
                        print(f"[RESUME WARN] Khong the tinh hash tu image_data: {e}")
            
            # Kiem tra 3: File thuc su da ton tai tren disk?
            if file_path.exists():
                file_hash = self.calculate_file_hash(file_path)
                if file_hash and file_hash in self.existing_hashes:
                    if self.debug:
                        print(f"[RESUME WARN] File tren disk co hash da ton tai")
                    return False
            
            # Tat ca check passed
            return True
            
        except Exception as e:
            if self.debug:
                print(f"[RESUME ERROR] Loi khi kiem tra file: {e}")
            # Neu co loi, van cho phep luu de tranh mat du lieu
            return True
    
    def register_saved_file(self, file_path, image_data=None):
        """
        Dang ky file da duoc luu thanh cong
        
        Args:
            file_path: Duong dan file da luu
            image_data: Du lieu anh (optional)
            
        Returns:
            True neu thanh cong
        """
        try:
            file_path = Path(file_path)
            
            # Them vao danh sach file
            self.existing_files.add(str(file_path))
            
            # Tang event count
            self.event_count += 1
            
            # Tinh hash neu co image_data
            if image_data is not None:
                try:
                    import numpy as np
                    if isinstance(image_data, np.ndarray):
                        image_bytes = image_data.tobytes()
                        data_hash = hashlib.md5(image_bytes).hexdigest()
                        self.existing_hashes.add(data_hash)
                except:
                    pass
            
            # Tinh hash tu file tren disk
            file_hash = self.calculate_file_hash(file_path)
            if file_hash:
                self.existing_hashes.add(file_hash)
            
            # Luu checkpoint sau moi checkpoint_interval events
            if self.event_count - self.last_checkpoint >= self.checkpoint_interval:
                if self._save_checkpoint():
                    self.last_checkpoint = self.event_count
                    if self.debug:
                        print(f"[RESUME INFO] Checkpoint saved at event {self.event_count}")
            
            return True
            
        except Exception as e:
            if self.debug:
                print(f"[RESUME ERROR] Loi khi dang ky file: {e}")
            return False
    
    def get_stats(self):
        """
        Lay thong ke hien tai
        
        Returns:
            Dict chua thong tin thong ke
        """
        return {
            'event_count': self.event_count,
            'total_files': len(self.existing_files),
            'unique_hashes': len(self.existing_hashes),
            'last_checkpoint': self.last_checkpoint,
            'base_path': str(self.base_path),
            'checkpoint_file': str(self.checkpoint_file),
            'resume_enabled': self.resume
        }
    
    def print_stats(self):
        """
        In thong ke ra console
        """
        stats = self.get_stats()
        print("\n" + "="*50)
        print("DATASET RESUME STATISTICS")
        print("="*50)
        print(f"Base path: {stats['base_path']}")
        print(f"Resume enabled: {stats['resume_enabled']}")
        print(f"Total events recorded: {stats['event_count']}")
        print(f"Total files tracked: {stats['total_files']}")
        print(f"Unique image hashes: {stats['unique_hashes']}")
        print(f"Last checkpoint: {stats['last_checkpoint']}")
        print(f"Checkpoint file: {stats['checkpoint_file']}")
        
        # Hien thi file count theo thu muc
        mouse_path = self.base_path / 'Mouse'
        keyboard_path = self.base_path / 'Keyboard'
        
        if mouse_path.exists():
            mouse_files = len(list(mouse_path.glob('*.png')))
            print(f"Mouse events: {mouse_files}")
        
        if keyboard_path.exists():
            keyboard_files = len(list(keyboard_path.glob('*.png')))
            print(f"Keyboard events: {keyboard_files}")
        
        print("="*50 + "\n")
    
    def cleanup(self):
        """
        Don dep truoc khi ket thuc
        Luu checkpoint lan cuoi
        """
        if self.debug:
            print(f"[RESUME DEBUG] Dang cleanup...")
        
        self._save_checkpoint()
        
        if self.debug:
            print(f"[RESUME DEBUG] Cleanup hoan tat")
            self.print_stats()

# Debug/test function
def test_resume_manager():
    """
    Ham test Resume Manager
    """
    print("[TEST] Bat dau test Resume Manager")
    
    # Tao instance
    manager = DatasetResumeManager(
        base_path='./Test_Dataset',
        resume=True,
        checkpoint_interval=10,
        debug=True
    )
    
    # Scan dataset hien co
    manager.scan_existing_dataset()
    
    # In stats
    manager.print_stats()
    
    # Test should_save_file
    test_file = './Test_Dataset/test.png'
    print(f"\n[TEST] should_save_file('{test_file}'): {manager.should_save_file(test_file)}")
    
    # Cleanup
    manager.cleanup()
    
    print("[TEST] Test hoan tat")

if __name__ == "__main__":
    # Chay test neu goi truc tiep
    test_resume_manager()