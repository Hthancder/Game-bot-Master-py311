# Arda Mavi
import os
import numpy as np  # Fix: numpy -> np
from get_dataset import get_dataset
from get_model import get_model, save_model
from keras.callbacks import ModelCheckpoint, TensorBoard

epochs = 100
batch_size = 5

def train_model(model, X, X_test, Y, Y_test):
    checkpoints = []
    if not os.path.exists('Data/Checkpoints/'):
        os.makedirs('Data/Checkpoints/')

    # FIX: Thay period=1 bằng save_freq='epoch' cho Keras 2.x/TensorFlow 2.x
    # Kiểm tra Keras version để dùng đúng parameter
    try:
        import keras
        keras_version = keras.__version__
        print(f"[INFO] Keras version: {keras_version}")
        
        if keras_version.startswith('1.'):
            # Keras 1.x: dùng period
            checkpoint = ModelCheckpoint(
                'Data/Checkpoints/best_weights.h5',
                monitor='val_loss',
                verbose=1,  # Thêm verbose=1 để xem khi nào lưu
                save_best_only=True,
                save_weights_only=True,
                mode='auto',
                period=1
            )
        else:
            # Keras 2.x/TensorFlow 2.x: dùng save_freq
            checkpoint = ModelCheckpoint(
                'Data/Checkpoints/best_weights.h5',
                monitor='val_loss',
                verbose=1,
                save_best_only=True,
                save_weights_only=True,
                mode='auto',
                save_freq='epoch'  # THAY period=1 BẰNG save_freq='epoch'
            )
    except:
        # Fallback: dùng save_freq cho version mới
        checkpoint = ModelCheckpoint(
            'Data/Checkpoints/best_weights.h5',
            monitor='val_loss',
            verbose=1,
            save_best_only=True,
            save_weights_only=True,
            mode='auto',
            save_freq='epoch'
        )
    
    checkpoints.append(checkpoint)
    
    checkpoints.append(TensorBoard(
        log_dir='Data/Checkpoints/./logs',
        histogram_freq=0,
        write_graph=True,
        write_images=False,
        embeddings_freq=0,
        embeddings_layer_names=None,
        embeddings_metadata=None
    ))

    # Thêm EarlyStopping để tránh overfitting
    from keras.callbacks import EarlyStopping
    early_stop = EarlyStopping(
        monitor='val_loss',
        patience=10,
        restore_best_weights=True,
        verbose=1
    )
    checkpoints.append(early_stop)
    
    # Thêm ReduceLROnPlateau để điều chỉnh learning rate
    from keras.callbacks import ReduceLROnPlateau
    reduce_lr = ReduceLROnPlateau(
        monitor='val_loss',
        factor=0.5,
        patience=5,
        min_lr=1e-6,
        verbose=1
    )
    checkpoints.append(reduce_lr)

    # Train model với validation
    print(f"[INFO] Training với {len(X)} samples, test với {len(X_test)} samples")
    print(f"[INFO] Batch size: {batch_size}, Epochs: {epochs}")
    
    history = model.fit(
        X, Y,
        batch_size=batch_size,
        epochs=epochs,
        validation_data=(X_test, Y_test),
        shuffle=True,
        callbacks=checkpoints,
        verbose=1  # Hiển thị progress bar
    )
    
    # Lưu model cuối cùng
    save_model(model)
    
    # Vẽ đồ thị loss/accuracy (tùy chọn)
    try:
        import matplotlib.pyplot as plt
        
        # Plot training & validation loss values
        plt.figure(figsize=(12, 4))
        
        plt.subplot(1, 2, 1)
        plt.plot(history.history['loss'])
        plt.plot(history.history['val_loss'])
        plt.title('Model loss')
        plt.ylabel('Loss')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Validation'], loc='upper right')
        
        # Plot training & validation accuracy
        plt.subplot(1, 2, 2)
        plt.plot(history.history['accuracy'])
        plt.plot(history.history['val_accuracy'])
        plt.title('Model accuracy')
        plt.ylabel('Accuracy')
        plt.xlabel('Epoch')
        plt.legend(['Train', 'Validation'], loc='lower right')
        
        plt.tight_layout()
        plt.savefig('Data/Checkpoints/training_history.png')
        plt.close()
        print("[INFO] Đã lưu đồ thị training history")
    except Exception as e:
        print(f"[INFO] Không vẽ được đồ thị: {e}")
    
    return model

def main():
    # Lấy dataset
    print("[INFO] Đang tải dataset...")
    dataset = get_dataset()
    
    if dataset is None:
        print("[ERROR] Không tải được dataset!")
        return None
    
    X, X_test, Y, Y_test = dataset
    
    print(f"[INFO] Dataset: X.shape={X.shape}, Y.shape={Y.shape}")
    print(f"[INFO] Test set: X_test.shape={X_test.shape}, Y_test.shape={Y_test.shape}")
    
    # Tạo model
    print("[INFO] Đang tạo model...")
    model = get_model()
    
    # Hiển thị model summary
    try:
        model.summary()
    except:
        pass
    
    # Train model
    print("[INFO] Bắt đầu training...")
    model = train_model(model, X, X_test, Y, Y_test)
    
    # Evaluate model
    print("[INFO] Đánh giá model...")
    loss, accuracy = model.evaluate(X_test, Y_test, verbose=0)
    print(f"[RESULT] Test Loss: {loss:.4f}, Test Accuracy: {accuracy:.4f}")
    
    return model

if __name__ == '__main__':
    model = main()
    if model:
        print("[INFO] Training hoàn tất!")
    else:
        print("[ERROR] Training thất bại!")